# -*- coding: utf-8 -*-


from ._git import (getRepoName, addTokenToURL, 
                   getTokensFromGDrive, addTokenFromGDriveToURL, 
                   pipInstallRepo, cloneRepo, setAccessURL, setRemoteURL, removeRemote, 
                   download_git_file, download_git_folder)