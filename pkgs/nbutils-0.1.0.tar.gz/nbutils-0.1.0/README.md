# PyExamsUtils: Jupyter Notebook Utilities for Designing Exams with R/exams

Welcome to PyExamsUtil, a Python utility library designed to streamline the integration and usage of the R/Exams package in Google Colab and Jupyter environmets for exam generation.

## Getting Started

To get started with PyExamsUtil, follow these simple steps:

### Prerequisites

### Installation

You can install PyExamsUtil using pip:
