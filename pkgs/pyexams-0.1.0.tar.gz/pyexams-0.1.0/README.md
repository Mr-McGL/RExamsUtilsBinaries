# pyexams: Jupyter Notebook Utilities for Designing Exams with R/exams

Welcome to pyexams, a Python utility library designed to streamline the integration and usage of the R/Exams package in Google Colab and Jupyter environmets for exam generation.

## Getting Started

To get started with pyexams, follow these simple steps:

### Prerequisites

### Installation

You can install pyexams using pip:
