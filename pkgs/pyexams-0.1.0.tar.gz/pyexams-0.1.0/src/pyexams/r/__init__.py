# -*- coding: utf-8 -*-


from ._run import run
from ._output import set_warnerr_cb, set_console_cb